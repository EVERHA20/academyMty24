package com.luv2code.component.models;

public interface Student {

    String studentInformation();

    String getFullName();
}
